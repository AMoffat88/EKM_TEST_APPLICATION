﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EKM_Test_Application
{
	public class RentalViewModel
	{
		public int CurrentFilmCount { get; set; }
		public int CurrentUserCount { get; set; }


		public IEnumerable<FilmViewModel> Films { get; set; }
		public IEnumerable<UserViewModel> Users { get; set; }
		public FilmViewModel DefaultFilmViewModel { get; set; }
		public UserViewModel DefaultUserViewModel { get; set; }
	}
}