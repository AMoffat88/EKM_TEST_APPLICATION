﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EKM_Test_Application
{
	public class FilmViewModel
	{
		[Display(Name = "Id")]
		public int Id { get; set; }
		[DisplayName("Film Name")]
		public string FilmName { get; set; }
		public DateTime ReleaseDate { get; set; }
		[DisplayName("Film Type")]
		public string FilmType { get; set; }

	}
}