﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.WebControls;

namespace EKM_Test_Application
{
	//this is not the modern entity framework.
	//I had issues setting this up. So, I used a simple sql layer to achieve the required objective.
	public class DatabaseAccess
	{
		string sqlConnectionString;
		
		public DatabaseAccess()
		{
			sqlConnectionString = $"Server=localhost;Database=EKM_TECH_Library_DB;Trusted_Connection=True;";	
		}


		//this is a simple db test to ensure that the db does to ensure connectivity.
		public bool TestDBConnection()
		{
			using (SqlConnection connection = new SqlConnection(sqlConnectionString))
			try
			{
					connection.Open();
					connection.Close();
					return true;
			}
			catch(SqlException ex)
			{
				ex.ToString();
				return false;
			}
		}

		/// user table crud functionality
		/// create user
		public void CreateUser(string firstName, string lastName, int age)
		{
			try
			{
				string query = $"insert into dbo.USERS (USER_FIRST_NAME, USER_SECOND_NAME, USER_AGE) Values (@firstName, @lastName, @Age)";
				using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
				{
					using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
					{
						sqlCommand.Parameters.AddWithValue("@firstName", firstName);
						sqlCommand.Parameters.AddWithValue("@lastName", lastName);
						sqlCommand.Parameters.AddWithValue("@Age", age);

						ExecuteCommand(sqlCommand, sqlConnection);
					}
				}
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex);
			}

			
		}

		//read user table
		public List<UserViewModel> ReadUsers()
		{
			string query = $"select * from dbo.USERS";
			try
			{
				var users = new List<UserViewModel>();
				using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
				{
					using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
					{
						sqlConnection.Open();
						using (IDataReader reader = sqlCommand.ExecuteReader())
						{
							users = reader.Select(r => new UserViewModel
							{
								Id = r["USER_IDS"] is DBNull ? 0 : int.Parse(r["USER_IDS"].ToString()),
								FirstName = r["USER_FIRST_NAME"] is DBNull ? null : r["USER_FIRST_NAME"].ToString(),
								LastName = r["USER_SECOND_NAME"] is DBNull ? null : r["USER_SECOND_NAME"].ToString(),
								Age = r["USER_AGE"] is DBNull ? 0 : int.Parse(r["USER_AGE"].ToString())
							}).ToList();
						}
						sqlConnection.Close();
						return users;
					}
				}
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex);
				return new List<UserViewModel>();
			}
		}
		//update User details
		public void UpdateUsers(int id, string firstName, string lastName, int age)
		{
			string query = $"Update dbo.USERS(First_Name, Last_Name, Age) values(@firstName, @lastName, @Age) where @id = users.id";

			using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
			{
				using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
				{
					sqlCommand.Parameters.AddWithValue("@id", id);

					sqlCommand.Parameters.AddWithValue("@firstName", firstName);
					sqlCommand.Parameters.AddWithValue("@lastName", lastName);
					sqlCommand.Parameters.AddWithValue("@Age", age);

					ExecuteCommand(sqlCommand, sqlConnection);
				}
			}
		}
		//Delete User Record
		public void DeleteUsers(int id)
		{
			var query = $"Delete * from dbo.Users where @id = id";

			using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
			{
				using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
				{
					sqlCommand.Parameters.AddWithValue("@id", id);

					sqlConnection.Open();
					sqlCommand.ExecuteNonQuery();
					sqlConnection.Close();
				}
			}
		}


		//creates the film
		public void CreateFilm(string filmName, string FilmType)
		{
			var query = $"insert into dbo.FILM_COLLECTION (Film_Name, Film_Type) values (@filmName, @filmType)";
			try
			{
				using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
				{
					using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
					{
						sqlCommand.Parameters.AddWithValue("@filmName", filmName);
						sqlCommand.Parameters.AddWithValue("@FilmType", FilmType);

						ExecuteCommand(sqlCommand, sqlConnection);
					}
				}
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex);
			}

		}

		//read films
		public List<FilmViewModel> ReadFilms()
		{
			List<FilmViewModel> films = new List<FilmViewModel>();
			string query = $"select * from dbo.FILM_COLLECTION";
			using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
			{
				using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
				{
					sqlConnection.Open();

					using (IDataReader reader = sqlCommand.ExecuteReader())
					{
						films = reader.Select(r => new FilmViewModel
						{
							Id = r["Film_Id"] is DBNull ? 0 : int.Parse(r["Film_Id"].ToString()),
							FilmName = r["Film_Name"] is DBNull ? null : r["Film_Name"].ToString(),
							FilmType = r["Film_Type"] is DBNull ? null : r["Film_Type"].ToString()
						}).ToList();
					}
				}
			}
			return films;
		}
		//update the film collection
		public void UpdateFilms(int id, string filmName, DateTime ReleaseDate, string FilmType)
		{
			string query = $"Update dbo.FILM_COLLECTION (Film_Name, Release_Date, Film_Type) values (@filmName, @releaseDate, @filmType) where @id = Film_Id";

			using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
			{
				using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
				{
					sqlCommand.Parameters.AddWithValue("@id", id);
					sqlCommand.Parameters.AddWithValue("@filmName", filmName);
					sqlCommand.Parameters.AddWithValue("@releaseData", ReleaseDate);
					sqlCommand.Parameters.AddWithValue("@FilmType", FilmType);

					ExecuteCommand(sqlCommand, sqlConnection);
				}
			}

		}
		//delete from film collection
		public void DeleteFilm(int id)
		{
			string query = $"Delete from dbo.FILM_COLLECTION where Film_Id = @id";
			using (SqlConnection sqlConnection = new SqlConnection(sqlConnectionString))
			{
				using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
				{
					sqlCommand.Parameters.AddWithValue("@id", id);

					ExecuteCommand(sqlCommand, sqlConnection);
				}
			}
		}





		//just tidies up a little reptitive code
		public void ExecuteCommand(SqlCommand sqlCommand, SqlConnection sqlConnection)
		{
			sqlConnection.Open();
			int result = sqlCommand.ExecuteNonQuery();

			if (result < 0)
			{
				Console.WriteLine("Error in writing to DB");
			}
			sqlConnection.Close();
		}
	}
	static class ListExtensions
	{
		public static IEnumerable<T> Select<T>(this IDataReader dataReader, Func<IDataReader, T> Projection)
		{
			while (dataReader.Read())
			{
				yield return Projection(dataReader);
			}
		}
	}
}