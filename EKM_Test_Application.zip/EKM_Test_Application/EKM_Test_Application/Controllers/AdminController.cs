﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//the logic behind this is too have all of the logic accessible from one controller, keeping it simple.
//For larger applications it may be ideal to split this out.
namespace EKM_Test_Application.Controllers
{
    public class AdminController : Controller
    {
        DatabaseAccess dba;
        RentalViewModel rentalModel;
        public AdminController()
		{
            dba = new DatabaseAccess();
            rentalModel = new RentalViewModel();
            
		}

        public ActionResult AdminOverview()
		{
            rentalModel.CurrentUserCount = dba.ReadUsers().Count();
            rentalModel.CurrentFilmCount = dba.ReadFilms().Count();

            return View("AdminOverView", rentalModel);
		}

        // GET: Film
        public ActionResult FilmIndex()
        {
            rentalModel.Films = dba.ReadFilms();

            return View("Film/FilmIndex",rentalModel);
        }

        public ActionResult UserIndex()
		{
            rentalModel.Users = dba.ReadUsers();

            return View("User/UserIndex", rentalModel);
		}

		// GET: Film/Create
		public ActionResult FilmCreate()
		{
			return View("Film/Create");
		}

		// POST: Film/Create
        [HttpPost]
		public ActionResult FilmCreate(FilmViewModel Model)
        {
            try
            {
                dba.CreateFilm(Model.FilmName, Model.FilmType);

                return RedirectToAction("FilmIndex");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult UserCreate()
		{
            return View("User/Create");
		}
        [HttpPost]
        public ActionResult UserCreate(UserViewModel Model)
		{
			try
			{
                dba.CreateUser(Model.FirstName, Model.LastName, Model.Age);

                return RedirectToAction("UserIndex");
			}
            catch
			{
                return View();
			}
		}


        //// GET: Film/Edit/5
        //public ActionResult Edit(int id)
        //{
        //    return View();
        //}

        //// POST: Film/Edit/5
        //[HttpPost]
        //public ActionResult Edit(int id, FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add update logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        // GET: Film/Delete/5
        public ActionResult DeleteFilm(int? id)
        {
            int _id = (int)id;
            dba.DeleteFilm(_id);
            return RedirectToAction("FilmIndex");
        }

        // POST: Film/Delete/5
        [HttpPost]
        public ActionResult DeleteFilm(FilmViewModel filmViewModel)
        {
            try
            {
                dba.DeleteFilm(filmViewModel.Id);

                return RedirectToAction("FilmIndex");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult DeleteUser(int? id)
		{
            int _id = (int)id;

            dba.DeleteFilm(_id);
            return RedirectToAction("UserIndex");
		}

    }
}
